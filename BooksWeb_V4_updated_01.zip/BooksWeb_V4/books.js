try{
    var {search}= require('./utils.js')
}catch(e){

}

var books = [
    {
        id: 'the-accursed-god',
        title: 'The Accursed God',
        author: 'Vivek Dutta Mishra',
        cover: 'https://m.media-amazon.com/images/I/41xektjU1NL._SY445_SX342_.jpg',
        price: 399,
        rating: 4.5,
        reviews: [
            { rating: 5, name: 'Sanjay', title: 'Great Book', text: 'A book of Mahabharata. Waiting for the second part' },
            { rating: 4, name: 'Shivanshi', title: 'Interesting but complicated', text: 'A book of Mahabharata. The beginning appears confusing' },
            { rating: 5, name: 'Prabhat', title: 'Ineteresting Plot', text: 'A book of Mahabharata. Waiting for the second part' },

        ]
    },
    {
        id: 'rashmirathi',
        title: 'Rashmirathi',
        author: 'Ramdhari Singh Dinkar',
        cover: 'https://m.media-amazon.com/images/I/51ForZD4R5L._SY445_SX342_.jpg',
        price: 99,
        rating: 4.7,
        reviews: [
            { rating: 5, name: 'Vivek', title: 'My Favorite', text: 'Finest poetry, unfortuately not factual' },
            { rating: 4, name: 'Shivanshi', title: 'Interesting but complicated', text: 'Was not aware of many things written in the book' },
            { rating: 5, name: 'Prabhat', title: 'Ineteresting Plot', text: 'A book of Mahabharata. Waiting for the second part' },

        ]
    },
    {
        id: 'the-count-of-monte-cristo',
        title: 'The Count of Mone Cristo',
        author: 'Alexandre Dumas',
        cover: 'https://m.media-amazon.com/images/I/415bCctFbxL._SY445_SX342_.jpg',
        price: 499,
        rating: 4.8,
        reviews: [
            { rating: 5, name: 'Vivek', title: 'One of the greatest classic', text: 'One of my altime favorite books. Read several times' },
            { rating: 5, name: 'Shivanshi', title: 'Nice Plot', text: 'An excellent book' },
            { rating: 5, name: 'Reena', title: 'Ineteresting Plot', text: 'A book of Mahabharata. Waiting for the second part' },

        ]
    },
    {
        id: 'manas',
        title: 'Manas',
        author: 'Vivek Dutta Mishra',
        cover: 'https://m.media-amazon.com/images/I/412eqQc7WNL._SY445_SX342_.jpg',
        price: 199,
        rating: 4.7,
        reviews: [
            { rating: 5, name: 'Sanjay', title: 'Great Book', text: 'A book of Mahabharata in a poetic format. Read several times' },
            { rating: 4, name: 'Shivanshi', title: 'Myth Buster', text: 'Answers several myths of Mahabharata' },
            { rating: 5, name: 'Prabhat', title: 'Mahabharata Courtroom', text: 'A book of Mahabharata. Waiting for the second part' },

        ]
    },
]



function handleAddBook() {
    let title = document.getElementById("title").value;
    let author = document.getElementById("author").value;
    let cover = document.getElementById("cover").value;
    let price = document.getElementById("price").value;
    console.log(title);
    const book = {
        id: title.toLowerCase().replace(/ /g, "-"),
        title: title,
        author: author,
        cover: cover,
        price: +price,
        rating: 1,
        reviews: [],
    }
    addBook(book);

}

function addBook(book) {
    console.log("inside addBook")
    const storedData = localStorage.getItem('books');
    const b = JSON.parse(storedData);
    console.log("previous books: ", b);
    //write validation logic to check book info is present
    if (!book.title)
        return "Invalid Title";
    if (!book.author)
        return "Missing Author";
    if (!book.price || isNaN(book.price) || book.price < 0)
        return "Invalid Price";
    if (!book.rating || isNaN(book.rating) || book.rating < 1 || book.rating > 5)
        return "Invalid Rating";
    
    b.push(book); //save to database;
    localStorage.setItem('books', JSON.stringify(b));   
    console.log("book added to database successfully.")
    console.log("after adding: ", b);

    return null; //no error.
}


function sortOnPrice(books) {

    //let books=displayBooks;
    //let sorted;

  swap(books,(b1, b2)=>b1.price<=b2.price)
    //console.log(books);
    //showBookCards(books);

    return books;
}


function sortOnRating(books) {
    // let size = books.length;
    //let books=displayBooks;
    swap(books,(b1, b2)=>b1.rating<=b2.rating)
    //console.log(books);
    //showBookCards(books);

    return books;
}

function sortOnAuthor(books) {
    //let books=displayBooks;

    swap(books, (b1,b2)=>{
        if(b1.author===b2.author){
            return b1.title<=b2.title;
        }
        else{
            return b1.author<=b2.author;
        }
});
    //showBookCards(books);
    return books;
}

function sortOnTitle(books) {
    //let books=displayBooks;

    swap(books,(b1, b2)=>b1.title<=b2.title);
    //showBookCards(books);
    return books;
}

var byAuthor = function (author) {
    return book => book.author.toLowerCase().includes(author);
}

var searchByAuthor=function(books,author){
    author=author.toLowerCase();
    return search(books, byAuthor(author));
}

var byTitle = function (title) {
    return book => book.title.toLowerCase().includes(title);
}

var searchByTitle=function(books,title){
    title=title.toLowerCase();
    return search(books, byTitle(title));
}

var byRange = function (rangeCriteria,min, max) {
    return book => book[rangeCriteria] >= min && book[rangeCriteria] <= max;
}

var searchByPriceRange=function(books,min,max){
    return search(books, byRange('price',min, max));
}
var searchByRatingRange=function(books,min,max){
    return search(books, byRange('rating',min, max));
}

try {

    module.exports = {
        books: books,
        addBook: addBook,
        sortOnAuthor,
        sortOnTitle,//same as sortOnAuthor:sortOnAuthor
        sortOnPrice,
        sortOnRating,
        searchByAuthor,
        searchByTitle,
        searchByPriceRange,
        searchByRatingRange,
        handleAddBook,
    }
} catch (e) {
    //web application.
    //no harm done.
}