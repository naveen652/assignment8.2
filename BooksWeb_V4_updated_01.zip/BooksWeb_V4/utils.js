function swap(list, isOrdered=(a,b)=>a<=b)
{
    let size = list.length;

    do {
        var sorted = true; //optimisitic assumption that the  list is sorted
        for (let i = 0; i < size - 1; i++) {
            if (!isOrdered(list[i],list[i+1])) {
                let temp = list[i];
                list[i] = list[i + 1];
                list[i + 1] = temp;
                sorted = false; //oh! my assumption was wrong
            }
        }
        size--;
    } while (!sorted);

}



function search(list, match) {

    let result = [];
    for (let item of list) {
        if (match(item))//check if item is a match
            result.push(item);
    }
    return result;
}

try{
    module.exports={
        search,
        swap
    }
}catch(e){
    
}
