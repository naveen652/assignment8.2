//let b = require('./books');
// let books=b.books;
// let sortOnPrice=b.sortOnPrice;
// let search=b.search;
try{

    var {books, sortOnPrice,searchByTitle,searchByPriceRange, sortOnRating, sortOnAuthor, sortOnTitle} = require('./books')
}catch(e){
    //its a web app.
    //no problem functions are included.
}


let app= (function(){
    let selectedBooks;;
    
    function showBooks(books,message=''){

        if(!books || !books.length)
            message+= '<span class="error">No books Found</span>';

        let messageArea = document.getElementById('messageArea');
        messageArea.innerHTML = message;
        
        let booksDiv= document.getElementById('books');
        let cards = '';
    
        for (let book of books) {
            let card = `
            <div class="card" id="${book.id}">
                    <img 
                        id="image-1"
                        src="${book.cover}"
                        alt="${book.title}"
                        title="${book.title}"
                        class="book_thumbnail"
                    />
                    <div class="title" >${book.title}</div>
                    <div class="subtitle" >${book.author}</div>
                    <div class="label">${book.price}</div>
                    <div class="label">${book.rating}</div>
                    <a class="action-link" href="book1.html">Details</a>
                    
            </div>        
            `
            cards += card;
        }
        booksDiv.innerHTML = cards;
    }
    
    function handleSortOnPrice(){
        sortOnPrice(selectedBooks);
        showBooks(selectedBooks,'Sort on Price');
    }

    function handleSortOnRating(){
        sortOnRating(selectedBooks);
        showBooks(selectedBooks,'Sorted on Rating');
    }

    function handleSortOnAuthor(){
        sortOnAuthor(selectedBooks);
        showBooks(selectedBooks, 'Sorted on Author');
    }

    function handleSortOnTitle(){
        sortOnTitle(selectedBooks);
        showBooks(selectedBooks, 'Sorted on Title');
    }

    function handleGetAllBooks() {
        selectedBooks = books;
        showBooks(selectedBooks, 'All Books');
        return books;
    }

    function init(){
        selectedBooks = books;
        searchDropdown();
        showBooks(selectedBooks);
    }
    let criteriaList= document.getElementById('criteria');
    let searchText = document.getElementById('search');

    function getRange(query) {
        let minValue = document.getElementById("min").value;
        let maxValue = document.getElementById("max").value;
        // query += `${min} to ${max}`;
        
        return [minValue,maxValue];
    }

    const searchCriterias = {
        "All Books": handleGetAllBooks,
        "Author": searchByAuthor,
        "Title": searchByTitle,
        "Price Range": (items,query)=> searchByPriceRange(items,...getRange(query)),
        "Rating Range": (item,query)=>{
            var range= getRange(query);
            return search(selectedBooks,(book)=> book.rating>=range[0] && book.rating<=range[1])
        }
    }

    function searchDropdown() {
        let searchSelect = document.getElementById("criteria");
        let sortSelect = document.getElementById('orderBy');
        let searchOptions = '';
        let sortOptions = '';
        for (let i in searchCriterias) {
            let searchOptionHTML = `<option>${i}</option>`
            searchOptions += searchOptionHTML;
        }
        for (let i in sortCriterias) {
            let sortOptionHTML = `<option>${i}</option>`
            sortOptions += sortOptionHTML;
        }
        searchSelect.innerHTML = searchOptions;
        sortSelect.innerHTML = sortOptions;

    }

    let min = document.getElementById("min");
    let max = document.getElementById("max");
    function handleSearch() {
        let criteria = criteriaList.value;
        let query = searchText.value;
        console.log(min.style.display);
        
        if (!query&&min.value.length) {
            query = `${min.value} to ${max.value}`;
        }
        let result;
        console.log('criteria', criteria);
        let searchFunction = searchCriterias[criteria];

        if (searchFunction) {
            result = searchFunction(selectedBooks, query);
            console.debug(result, "result");
        }
        else {
            showBooks(selectedBooks, `<span class='error'>Invalid Search criteria</span>`);
            return;
        }

        
        if (result.length) {
            selectedBooks = result;
            showBooks(selectedBooks, `Books with ${criteria} ${query?"=":""} ${query}`);
        } else
            showBooks(selectedBooks, `<span class='error'>No Books matching ${criteria} ${query}</span>`);
    }
    function handleSearchCriteriaChange(){
        console.log('New search criteria', criteriaList.value);
        let criteria = criteriaList.value;
        searchText.value = '';
        min.value = ""
        max.value=""
        let displaySearchFields = displayType[criteria];
        if (displaySearchFields) {
            displaySearchFields();
        }
    }


    // let orderBy = document.getElementById('orderBy');
    const sortCriterias = {

        "Author": sortOnAuthor,
        "Title": sortOnTitle,
        "Price": sortOnPrice,
        "Rating": sortOnRating
    }



    function handleSort(){
        let orderBy= document.getElementById('orderBy').value;
        let result;
        console.log('orderBy',orderBy);
        let sortFunction = sortCriterias[orderBy];

        if(sortFunction) {
            result=sortFunction(selectedBooks);
        }
        else{
            showBooks(selectedBooks,`<span class='error'>Invalid Sort criteria</span>`);
            return;
        }

        
        if(result.length){
            selectedBooks=result;
            showBooks(selectedBooks,`Books with ${orderBy}`);
        }else
            showBooks(selectedBooks,`<span class='error'>No Books matching ${orderBy}</span>`);
    }

    function handleAllBooksHTML() {
        document.getElementById("search").style.display = "none";
        document.getElementById("submitSearch").style.display = "inline";
        document.getElementById("min").style.display = "none";
        document.getElementById("max").style.display = "none";
    }

    function handleTitleAuthorHTML() {
        document.getElementById("submitSearch").style.display = "inline";
        document.getElementById("search").style.display = "inline";
        document.getElementById("min").style.display = "none";
        document.getElementById("max").style.display = "none";
    }

    function handlePriceRatingHTML(){
        document.getElementById("search").style.display = "none";
        document.getElementById("min").style.display = "inline";
        document.getElementById("max").style.display = "inline";
        document.getElementById("submitSearch").style.display = "inline";
    }

    const displayType = {
        "All Books": handleAllBooksHTML,
        "Title": handleTitleAuthorHTML,
        "Author":handleTitleAuthorHTML,
        "Price Range": handlePriceRatingHTML,
        "Rating Range": handlePriceRatingHTML
    }

    

    //applicaiton object
    return {
        init,
        handleSortOnPrice,
        handleSortOnRating,
        handleSortOnAuthor,
        handleGetAllBooks,
        handleSearch,
        handleSort,
        handleSearchCriteriaChange,
        showBooks
    }

})()



